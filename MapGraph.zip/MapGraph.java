/**
 * @author UCSD MOOC development team 
 * @author RFlood 3/14/17
 * 
 * A class which reprsents a graph of geographic locations (vertices)
 * and connections between (edges)
 *
 */
package roadgraph;

import java.util.List;
import java.util.ListIterator;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.function.Consumer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;

import geography.GeographicPoint;
import util.GraphLoader;


public class MapGraph {
	private int numVertices;
	private int numEdges;
	
	//map of a lat/lon location to a vertex (instersection) object 
	private Map<GeographicPoint,MapVertex> vertices;  
	
	/** 
	 * Constructor - Create a new empty MapGraph 
	 */
	public MapGraph()
	{
		numVertices = 0;
		numEdges = 0;
		vertices = new HashMap<GeographicPoint,MapVertex>();
	}
	
	/**
	 * @return the number of vertices (road intersections) in the graph
	 */
	public int getNumVertices() { 
		return this.numVertices; 
	}
	
	/**
	 * Return the intersections, which are the vertices in this graph.
	 * @return The vertices in this graph as GeographicPoints
	 */
	public Set<GeographicPoint> getVertices() 
	{	
		// create a set to be returned
		HashSet<GeographicPoint> retSet = new HashSet<GeographicPoint>();
		// populate the return set with the keys (vertex locations) from the vertices Hash Map
		vertices.forEach((k,v) -> retSet.add(k));

		return retSet;
	}
	
	/**
	 * @return The number of edges (roads) in the graph.
	 */
	public int getNumEdges() { 
		return this.numEdges; 
	}

	/** Add a node corresponding to an intersection at a Geographic Point
	 * If the location is already in the graph or null, this method does 
	 * not change the graph.
	 * @param location  The location of the intersection
	 * @return true if a node was added, false if it was not (the node
	 * was already in the graph, or the parameter is null).
	 */
	public boolean addVertex(GeographicPoint location)
	{
		// check that the input location parameter is valid
		if (location.equals(null)) return false;
		// check if the node is already in the graph
		if (vertices.get(location) != null) return false;

	    // add the new vertex to the vertices hash map	
		numVertices ++;
		MapVertex vertex = new MapVertex(location);
		vertices.put(location, vertex);
		
		return true;
	}
	
	/**
	 * Adds a directed edge to the graph from pt1 to pt2.  
	 * Precondition: Both GeographicPoints have already been added to the graph
	 * @param from The starting point of the edge
	 * @param to The ending point of the edge
	 * @param roadName The name of the road
	 * @param roadType The type of the road
	 * @param length The length of the road, in km
	 * @throws IllegalArgumentException If the points have not already been
	 *   added as nodes to the graph, if any of the arguments is null,
	 *   or if the length is less than 0.
	 */
	public void addEdge(GeographicPoint from, GeographicPoint to, String roadName,
			String roadType, double length) throws IllegalArgumentException {

		// check for valid input -- throw an exception if some inputs are invalid
		if (vertices.get(from) == null || vertices.get(to) == null) 
			throw (new IllegalArgumentException("from or to location for the edge is not valid"));
		else if ((from == null) || (to == null) || (roadType == null))
			throw (new IllegalArgumentException("an expected input argument is null"));
		else if (length < 0)
			throw (new IllegalArgumentException("input length is less than zero"));
		
		numEdges ++;
		// create a new MapEdge object
		MapEdge edge = new MapEdge(from,to,roadName,roadType,length);
		
		// find the vertex for this start location (from loc)
		MapVertex v = vertices.get(from);
		// add this new MapEdge to the vertex's list of edges 
		v.setEdge(edge);
		
	}
	

	/** Find the path from start to goal using breadth first search
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @return The list of intersections that form the shortest (unweighted)
	 *   path from start to goal (including both start and goal).
	 */
	public List<GeographicPoint> bfs(GeographicPoint start, GeographicPoint goal) {
		// Dummy variable for calling the search algorithms
        Consumer<GeographicPoint> temp = (x) -> {};
        return bfs(start, goal, temp);
	}
	
	/** Find the path from start to goal using breadth first search
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @param nodeSearched A hook for visualization. 
	 * @return The list of intersections that form the shortest (unweighted)
	 *   path from start to goal (including both start and goal).
	 */
	public List<GeographicPoint> bfs(GeographicPoint start, 
			 					     GeographicPoint goal, Consumer<GeographicPoint> nodeSearched)
	{
		
		// make sure there are vertices for the start and goal locations
		if (vertices.get(start) == null || vertices.get(goal) == null)		{
			System.out.println("Start or goal location is not valid!  No path exists.");
			return null;  
		}
		
		// make a queue of the vertices that need to be explored to find the goal, a hash set of the
		// visited vertices, and a hashmap of the parent vertices (the path along the way)
		// Note: for a breadth first search, add vertices to the end of the queue and take them off from the front.
		Queue<MapVertex> toExplore = new LinkedList<MapVertex>();
		HashSet<MapVertex> visited = new HashSet<MapVertex>();
		HashMap<MapVertex, MapVertex> parentMap = new HashMap<MapVertex, MapVertex>();
		
		toExplore.add(vertices.get(start));  //the start vertex is at the top of the queue
		boolean found = false;
		while (!toExplore.isEmpty()) {
			
			// get a vertex from the top of the queue
			MapVertex curr = toExplore.remove();
			// check if we've found our goal
			if (goal.equals(curr.getLoc())) {
				found = true;
				break;
			}
			// for each of the edges of the current vertex, 
			// if the edge endloc vertex hasn't been already visited, 
			// mark it as visited, keep track of its parent, and add it to the end of the queue
			// also store this endloc in nodeSearched to show on visualization of map
			for (MapEdge e : curr.getEdges()) {
			    MapVertex edgeEndVertex = vertices.get(e.getEndLoc());
				if (!visited.contains(edgeEndVertex)) {    
					visited.add(edgeEndVertex);   
					parentMap.put(edgeEndVertex, curr);    
					toExplore.add(edgeEndVertex);
					nodeSearched.accept(e.getEndLoc());
				}		
			}      // end for loop through edges
		}          // while we still have vertices to explore			

		if (!found) {
			System.out.println("No path exists");
			return null;  
		}
		
		// path exists - so, return a list of the locations along the path 
		// reconstruct path starting at the goal loc and working back to the start loc
		
		LinkedList<GeographicPoint> retList = new LinkedList<GeographicPoint>();  
		retList.add(goal);
		MapVertex lastVertex = vertices.get(goal);
		MapVertex prevVertex;
		
		while (!start.equals(lastVertex.getLoc())) {
		   prevVertex = parentMap.get(lastVertex);
		   retList.addFirst(prevVertex.getLoc());  
		   lastVertex = prevVertex;
		}
		
		return retList;
		
	}
	
	

	/** Find the path from start to goal using Dijkstra's algorithm
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @return The list of intersections that form the shortest path from 
	 *   start to goal (including both start and goal).
	 */
	public List<GeographicPoint> dijkstra(GeographicPoint start, GeographicPoint goal) {
		// Dummy variable for calling the search algorithms
		// You do not need to change this method.
        Consumer<GeographicPoint> temp = (x) -> {};
        return dijkstra(start, goal, temp);
	}
	
	/** Find the path from start to goal using Dijkstra's algorithm
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @param nodeSearched A hook for visualization.  See assignment instructions for how to use it.
	 * @return The list of intersections that form the shortest path from 
	 *   start to goal (including both start and goal).
	 */
	public List<GeographicPoint> dijkstra(GeographicPoint start, 
										  GeographicPoint goal, Consumer<GeographicPoint> nodeSearched)
	{
		// TODO: Implement this method in WEEK 4

		// Hook for visualization.  See writeup.
		//nodeSearched.accept(next.getLocation());
		
		return null;
	}

	/** Find the path from start to goal using A-Star search
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @return The list of intersections that form the shortest path from 
	 *   start to goal (including both start and goal).
	 */
	public List<GeographicPoint> aStarSearch(GeographicPoint start, GeographicPoint goal) {
		// Dummy variable for calling the search algorithms
        Consumer<GeographicPoint> temp = (x) -> {};
        return aStarSearch(start, goal, temp);
	}
	
	/** Find the path from start to goal using A-Star search
	 * 
	 * @param start The starting location
	 * @param goal The goal location
	 * @param nodeSearched A hook for visualization.  See assignment instructions for how to use it.
	 * @return The list of intersections that form the shortest path from 
	 *   start to goal (including both start and goal).
	 */
	public List<GeographicPoint> aStarSearch(GeographicPoint start, 
											 GeographicPoint goal, Consumer<GeographicPoint> nodeSearched)
	{
		// TODO: Implement this method in WEEK 4
		
		// Hook for visualization.  See writeup.
		//nodeSearched.accept(next.getLocation());
		
		return null;
	}


	public static void main(String[] args)
	{
		System.out.print("Making a new map...");
		MapGraph firstMap = new MapGraph();
		System.out.print("DONE. \nLoading the map...");
		GraphLoader.loadRoadMap("data/testdata/simpletest.map", firstMap);
		System.out.println("DONE.");
		
		// You can use this method for testing.  
		
		System.out.println("---the number of vertices is "+firstMap.getNumVertices());
		//firstMap.vertices.forEach((k,v) -> System.out.println("key: "+k+" value: "+v.toString()));
        for (GeographicPoint p : firstMap.vertices.keySet()) {
			System.out.println("vertex at "+p.toString());
		}
		
		System.out.println("---the number of edges is "+firstMap.getNumEdges());
		for (GeographicPoint p : firstMap.vertices.keySet()) {
			MapVertex v = firstMap.vertices.get(p);
			System.out.println(v.toString());
			//System.out.println("vertex at "+p.toString());
		}
		
		System.out.println("---testing getVertices method");
		Set<GeographicPoint> rftrial = firstMap.getVertices();
        for (GeographicPoint p : rftrial) { 
        	System.out.println("vertex at "+p.toString());
        }
        
        System.out.println("---testing bfs route");
		GeographicPoint testStart = new GeographicPoint(1, 1);
		GeographicPoint testEnd = new GeographicPoint(8, -1);
		
		List<GeographicPoint> testRoute = firstMap.bfs(testStart, testEnd);
		if (testRoute == null)  System.out.println(" test route is null");
		else System.out.println("length of route is "+testRoute.size()+"\n"+testRoute);
		
		/* Here are some test cases you should try before you attempt 
		 * the Week 3 End of Week Quiz, EVEN IF you score 100% on the 
		 * programming assignment.
		 */
		/*
		MapGraph simpleTestMap = new MapGraph();
		GraphLoader.loadRoadMap("data/testdata/simpletest.map", simpleTestMap);
		
		GeographicPoint testStart = new GeographicPoint(1.0, 1.0);
		GeographicPoint testEnd = new GeographicPoint(8.0, -1.0);
		
		System.out.println("Test 1 using simpletest: Dijkstra should be 9 and AStar should be 5");
		List<GeographicPoint> testroute = simpleTestMap.dijkstra(testStart,testEnd);
		List<GeographicPoint> testroute2 = simpleTestMap.aStarSearch(testStart,testEnd);
		
		
		MapGraph testMap = new MapGraph();
		GraphLoader.loadRoadMap("data/maps/utc.map", testMap);
		
		// A very simple test using real data
		testStart = new GeographicPoint(32.869423, -117.220917);
		testEnd = new GeographicPoint(32.869255, -117.216927);
		System.out.println("Test 2 using utc: Dijkstra should be 13 and AStar should be 5");
		testroute = testMap.dijkstra(testStart,testEnd);
		testroute2 = testMap.aStarSearch(testStart,testEnd);
		
		
		// A slightly more complex test using real data
		testStart = new GeographicPoint(32.8674388, -117.2190213);
		testEnd = new GeographicPoint(32.8697828, -117.2244506);
		System.out.println("Test 3 using utc: Dijkstra should be 37 and AStar should be 10");
		testroute = testMap.dijkstra(testStart,testEnd);
		testroute2 = testMap.aStarSearch(testStart,testEnd);
		*/
		
		
		/* Use this code in Week 3 End of Week Quiz */
		/*MapGraph theMap = new MapGraph();
		System.out.print("DONE. \nLoading the map...");
		GraphLoader.loadRoadMap("data/maps/utc.map", theMap);
		System.out.println("DONE.");

		GeographicPoint start = new GeographicPoint(32.8648772, -117.2254046);
		GeographicPoint end = new GeographicPoint(32.8660691, -117.217393);
		
		
		List<GeographicPoint> route = theMap.dijkstra(start,end);
		List<GeographicPoint> route2 = theMap.aStarSearch(start,end);

		*/
		
	}
	
}
